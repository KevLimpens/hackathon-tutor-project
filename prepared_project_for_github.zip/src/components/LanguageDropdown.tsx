import React, { useState, useRef, useEffect } from 'react';
import { ChevronDown } from 'lucide-react';
import { languages } from '../data/languages';
import { Language } from '../types/language';

interface LanguageDropdownProps {
  currentLanguage: string;
  onLanguageChange: (languageCode: string) => void;
}

const LanguageDropdown: React.FC<LanguageDropdownProps> = ({
  currentLanguage,
  onLanguageChange,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const currentLang = languages.find(lang => lang.code === currentLanguage) || languages[0];

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleLanguageSelect = (language: Language) => {
    onLanguageChange(language.code);
    setIsOpen(false);
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-2 rounded-2xl glass-button transition-all duration-200 scale-95"
      >
        <img 
          src={currentLang.flag} 
          alt={currentLang.name}
          className="w-5 h-3 object-cover rounded-sm shadow-sm"
        />
        <ChevronDown className={`w-3 h-3 text-gray-700 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div className="absolute right-0 top-full mt-2 w-48 glass-dropdown rounded-2xl shadow-2xl overflow-hidden z-[100] scale-95 origin-top-right">
          {languages.map((language) => (
            <button
              key={language.code}
              onClick={() => handleLanguageSelect(language)}
              className={`w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-white/10 transition-all duration-200 ${
                currentLanguage === language.code ? 'bg-white/5' : ''
              }`}
            >
              <img 
                src={language.flag} 
                alt={language.name}
                className="w-5 h-3 object-cover rounded-sm shadow-sm flex-shrink-0"
              />
              <span className="text-gray-800 font-medium text-sm">{language.name}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default LanguageDropdown;