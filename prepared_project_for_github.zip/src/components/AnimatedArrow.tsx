import React from 'react';

const AnimatedArrow: React.FC = () => {
  return (
    <div className="flex items-center justify-center">
      <svg 
        width="42" 
        height="10" 
        viewBox="0 0 32 8" 
        fill="none" 
        xmlns="http://www.w3.org/2000/svg"
        className="text-white"
      >
        {/* Arrow body - 4x longer */}
        <line 
          x1="2" 
          y1="4" 
          x2="26" 
          y2="4" 
          stroke="currentColor" 
          strokeWidth="2" 
          strokeLinecap="round"
        />
        {/* Arrow head */}
        <polyline 
          points="22,1 26,4 22,7" 
          stroke="currentColor" 
          strokeWidth="2" 
          strokeLinecap="round" 
          strokeLinejoin="round"
        />
      </svg>
    </div>
  );
};

export default AnimatedArrow;