import React, { useState } from 'react';
import { LogIn, Mail, Lock, Eye, EyeOff, AlertCircle, CheckCircle, ArrowLeft, X, ArrowRight } from 'lucide-react';
import { signUp, signIn, signInWithGoogle, resetPassword } from '../lib/supabase';
import { useTranslation } from '../hooks/useTranslation';
import LanguageDropdown from './LanguageDropdown';
import PhysicsSpheres from './PhysicsSpheres';
import AnimatedArrow from './AnimatedArrow';

interface AuthFormProps {
  onSuccess: () => void;
  onDemoMode: () => void;
}

type AuthMode = 'login' | 'register' | 'forgot-password';

const AuthForm: React.FC<AuthFormProps> = ({ onSuccess, onDemoMode }) => {
  const { t, currentLanguage, changeLanguage } = useTranslation();
  const [mode, setMode] = useState<AuthMode>('login');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showVideoPopup, setShowVideoPopup] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [form, setForm] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    name: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value
    });
    // Clear message when user starts typing
    if (message) setMessage(null);
  };

  const validateForm = () => {
    if (mode === 'forgot-password') {
      if (!form.email) {
        setMessage({ type: 'error', text: t('email-required') });
        return false;
      }
      return true;
    }

    if (!form.email || !form.password) {
      setMessage({ type: 'error', text: t('email-password-required') });
      return false;
    }

    if (mode === 'register') {
      if (!form.name) {
        setMessage({ type: 'error', text: t('name-required') });
        return false;
      }
      if (form.password !== form.confirmPassword) {
        setMessage({ type: 'error', text: t('passwords-no-match') });
        return false;
      }
      if (form.password.length < 6) {
        setMessage({ type: 'error', text: t('password-min-length') });
        return false;
      }
    }

    return true;
  };

  const handleDemoMode = () => {
    setMessage({ type: 'success', text: 'Demo modus geactiveerd! Welkom bij LUCA-Tutor.' });
    setTimeout(() => {
      onDemoMode();
    }, 1000);
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setLoading(true);
    setMessage(null);

    try {
      if (mode === 'forgot-password') {
        const { error } = await resetPassword(form.email);
        
        if (error) {
          setMessage({ type: 'error', text: error.message });
        } else {
          setMessage({ 
            type: 'success', 
            text: t('password-reset-sent')
          });
        }
      } else if (mode === 'register') {
        const { data, error } = await signUp(form.email, form.password, form.name);
        
        if (error) {
          setMessage({ type: 'error', text: error.message });
        } else {
          setMessage({ 
            type: 'success', 
            text: t('registration-success-verify')
          });
          setMode('login');
          // Reset form
          setForm({ email: form.email, password: '', confirmPassword: '', name: '' });
        }
      } else {
        const { data, error } = await signIn(form.email, form.password);
        
        if (error) {
          if (error.message.includes('Email not confirmed')) {
            setMessage({ type: 'error', text: t('email-not-verified') });
          } else {
            setMessage({ type: 'error', text: t('invalid-credentials') });
          }
        } else {
          setMessage({ type: 'success', text: t('login-success') });
          // Call onSuccess immediately after successful login
          setTimeout(() => {
            onSuccess();
          }, 500);
        }
      }
    } catch (error: any) {
      setMessage({ type: 'error', text: error.message || t('unexpected-error') });
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleAuth = async () => {
    setLoading(true);
    setMessage(null);

    try {
      const { error } = await signInWithGoogle();
      
      if (error) {
        setMessage({ type: 'error', text: t('google-login-failed') + ': ' + error.message });
      }
      // Success will be handled by the auth state change listener
    } catch (error: any) {
      setMessage({ type: 'error', text: error.message || t('unexpected-error') });
    } finally {
      setLoading(false);
    }
  };

  const getTitle = () => {
    switch (mode) {
      case 'register': return t('create-account');
      case 'forgot-password': return t('reset-password');
      default: return 'LUCA-Tutor';
    }
  };

  const getDescription = () => {
    switch (mode) {
      case 'register': return t('create-account-desc');
      case 'forgot-password': return t('reset-password-desc');
      default: return 'Leren, Uitdrukken, Communiceren, Aanpassen!';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center p-4 relative">
      <div className="w-full max-w-md relative">
        {/* Minimized Physics Header - Now full width */}
        <div className="flex justify-center mb-8 relative z-50">
          <div className="glass-language-selector rounded-2xl px-6 py-3 shadow-2xl w-full">
            <div className="flex items-center justify-center gap-4">
              {/* Minimized Physics Spheres */}
              <div className="flex items-center">
                <PhysicsSpheres />
              </div>
              
              {/* Language Selection */}
              <div className="flex items-center gap-3">
                <AnimatedArrow />
                <span className="text-sm font-semibold text-white scale-105">{t('native-language')}:</span>
                <LanguageDropdown 
                  currentLanguage={currentLanguage}
                  onLanguageChange={changeLanguage}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Demo Mode Quick Access Button */}
        <div className="flex justify-center mb-6 relative z-50">
          <button
            onClick={handleDemoMode}
            className="glass-gradient-button text-white px-8 py-4 rounded-2xl font-semibold text-sm shadow-2xl hover:scale-105 transition-all duration-300 flex items-center gap-3"
          >
            <ArrowRight className="w-5 h-5" />
            Demo Modus - Direct naar LUCA-Tutor
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>

        {/* Divider */}
        <div className="relative mb-6">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-white/20"></div>
          </div>
          <div className="relative flex justify-center text-xs">
            <span className="px-4 bg-transparent text-white/70">of log in met je account</span>
          </div>
        </div>

        {/* Main Auth Card */}
        <div className="glass-card rounded-3xl p-8 shadow-2xl relative z-10">
          <div className="mb-8">
            {/* LUCA Image and Login Section */}
            <div className="flex items-center gap-6 mb-6">
              {/* LUCA Image - Left Side */}
              <div className="flex-shrink-0">
                <div className="relative group">
                  <button
                    onClick={() => setShowVideoPopup(true)}
                    className="block transition-transform duration-300 hover:scale-105 focus:outline-none focus:ring-4 focus:ring-purple-500/30 rounded-2xl"
                    title="Klik op LUCA voor meer informatie"
                  >
                    <img
                      src="https://fzzedvrabmtwuurzailn.supabase.co/storage/v1/object/public/media//klik%20hier.png"
                      alt="LUCA"
                      className="w-20 h-20 object-cover rounded-2xl shadow-lg"
                    />
                    {/* Hover overlay */}
                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-2xl flex items-center justify-center">
                      <span className="text-white text-xs font-medium text-center px-2">
                        Klik op LUCA voor meer informatie
                      </span>
                    </div>
                  </button>
                </div>
              </div>

              {/* Title and Login Icon - Right Side */}
              <div className="flex-1">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-3xl glass-button flex items-center justify-center">
                    {mode === 'forgot-password' ? (
                      <Mail className="w-8 h-8 text-white" />
                    ) : (
                      <LogIn className="w-8 h-8 text-white" />
                    )}
                  </div>
                  <div>
                    <h1 className="text-xl font-bold text-white mb-1">
                      {getTitle()}
                    </h1>
                    <p className="text-xs text-white/70">
                      {getDescription()}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Message Display */}
          {message && (
            <div className={`mb-6 p-4 rounded-2xl flex items-center gap-3 ${
              message.type === 'success' 
                ? 'glass-message success text-green-300' 
                : 'glass-message error text-red-300'
            }`}>
              {message.type === 'success' ? (
                <CheckCircle className="w-5 h-5 flex-shrink-0" />
              ) : (
                <AlertCircle className="w-5 h-5 flex-shrink-0" />
              )}
              <span className="text-xs">{message.text}</span>
            </div>
          )}

          {/* Email/Password Form */}
          <form onSubmit={handleEmailAuth} className="space-y-4 mb-6">
            {mode === 'register' && (
              <div>
                <label className="block text-xs font-medium text-white/90 mb-2">
                  {t('full-name')}
                </label>
                <input
                  type="text"
                  name="name"
                  value={form.name}
                  onChange={handleInputChange}
                  placeholder={t('full-name-placeholder')}
                  className="w-full p-3 glass-input rounded-2xl text-white placeholder-white/60 text-xs"
                  disabled={loading}
                  required
                />
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-white/90 mb-2">
                {t('email-address')}
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-white/60" />
                <input
                  type="email"
                  name="email"
                  value={form.email}
                  onChange={handleInputChange}
                  placeholder={t('email-placeholder')}
                  className="w-full p-3 pl-10 glass-input rounded-2xl text-white placeholder-white/60 text-xs"
                  disabled={loading}
                  required
                />
              </div>
            </div>

            {mode !== 'forgot-password' && (
              <div>
                <label className="block text-xs font-medium text-white/90 mb-2">
                  {t('password')}
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-white/60" />
                  <input
                    type={showPassword ? "text" : "password"}
                    name="password"
                    value={form.password}
                    onChange={handleInputChange}
                    placeholder={t('password-placeholder')}
                    className="w-full p-3 pl-10 pr-10 glass-input rounded-2xl text-white placeholder-white/60 text-xs"
                    disabled={loading}
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-white/60 hover:text-white/80"
                    disabled={loading}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            )}

            {mode === 'register' && (
              <div>
                <label className="block text-xs font-medium text-white/90 mb-2">
                  {t('confirm-password')}
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-white/60" />
                  <input
                    type={showConfirmPassword ? "text" : "password"}
                    name="confirmPassword"
                    value={form.confirmPassword}
                    onChange={handleInputChange}
                    placeholder={t('password-placeholder')}
                    className="w-full p-3 pl-10 pr-10 glass-input rounded-2xl text-white placeholder-white/60 text-xs"
                    disabled={loading}
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-white/60 hover:text-white/80"
                    disabled={loading}
                  >
                    {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full glass-gradient-button text-white py-3 rounded-2xl font-medium text-xs disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? t('processing') : 
                mode === 'forgot-password' ? t('send-reset-link') :
                mode === 'register' ? t('create-account-btn') : 
                t('login-btn')
              }
            </button>
          </form>

          {mode !== 'forgot-password' && (
            <>
              {/* Divider */}
              <div className="relative mb-6">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-white/20"></div>
                </div>
                <div className="relative flex justify-center text-xs">
                  <span className="px-4 bg-transparent text-white/70">{t('or')}</span>
                </div>
              </div>

              {/* Google Login Button */}
              <button
                onClick={handleGoogleAuth}
                disabled={loading}
                className="w-full glass-button text-white py-3 rounded-2xl font-medium flex items-center justify-center gap-3 text-xs disabled:opacity-50 disabled:cursor-not-allowed mb-6"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="currentColor" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="currentColor" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                  <path fill="currentColor" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                </svg>
                {loading ? t('processing') : 
                  mode === 'register' ? t('signup-google') : t('login-google')
                }
              </button>
            </>
          )}

          {/* Navigation Links */}
          <div className="text-center space-y-3">
            {mode === 'forgot-password' ? (
              <button
                onClick={() => {
                  setMode('login');
                  setMessage(null);
                  setForm({ email: form.email, password: '', confirmPassword: '', name: '' });
                }}
                className="flex items-center justify-center gap-2 text-xs text-white/70 hover:text-white transition-colors mx-auto"
                disabled={loading}
              >
                <ArrowLeft className="w-3 h-3" />
                {t('back-to-login')}
              </button>
            ) : (
              <>
                <button
                  onClick={() => {
                    setMode(mode === 'register' ? 'login' : 'register');
                    setMessage(null);
                    setForm({ email: '', password: '', confirmPassword: '', name: '' });
                  }}
                  className="text-xs text-white/70 hover:text-white transition-colors"
                  disabled={loading}
                >
                  {mode === 'register' ? t('have-account') : t('no-account')}
                </button>

                {mode === 'login' && (
                  <div>
                    <button 
                      onClick={() => {
                        setMode('forgot-password');
                        setMessage(null);
                        setForm({ email: form.email, password: '', confirmPassword: '', name: '' });
                      }}
                      className="text-xs text-purple-300 hover:text-purple-200 transition-colors" 
                      disabled={loading}
                    >
                      {t('forgot-password')}
                    </button>
                  </div>
                )}
              </>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-8 relative z-10">
          <p className="text-xs text-white/50">
            {t('terms-privacy')}
          </p>
        </div>
      </div>

      {/* Video Popup Modal */}
      {showVideoPopup && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="relative bg-black rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
            {/* Close Button */}
            <button
              onClick={() => setShowVideoPopup(false)}
              className="absolute top-4 right-4 z-10 w-10 h-10 bg-red-500 hover:bg-red-600 rounded-full flex items-center justify-center text-white transition-colors shadow-lg"
            >
              <X className="w-5 h-5" />
            </button>
            
            {/* Video */}
            <video
              src="https://fzzedvrabmtwuurzailn.supabase.co/storage/v1/object/public/media//luca%20introductie.mp4"
              controls
              autoPlay
              className="w-full h-auto max-h-[80vh] rounded-2xl"
              onError={(e) => {
                console.error('Video failed to load:', e);
                setMessage({ type: 'error', text: 'Video kon niet worden geladen' });
                setShowVideoPopup(false);
              }}
            >
              Je browser ondersteunt geen video playback.
            </video>
          </div>
        </div>
      )}
    </div>
  );
};

export default AuthForm;