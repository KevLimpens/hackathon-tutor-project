import React, { useState } from 'react';
import { User, Settings, Camera, Save, X } from 'lucide-react';
import { useUserProfile, useUserSettings } from '../hooks/useAuth';
import { useTranslation } from '../hooks/useTranslation';

interface UserProfileProps {
  isOpen: boolean;
  onClose: () => void;
}

const UserProfile: React.FC<UserProfileProps> = ({ isOpen, onClose }) => {
  const { t } = useTranslation();
  const { profile, updateProfile, updating: profileUpdating } = useUserProfile();
  const { settings, updateSettings, updating: settingsUpdating } = useUserSettings();
  
  const [activeTab, setActiveTab] = useState<'profile' | 'settings'>('profile');
  const [profileForm, setProfileForm] = useState({
    full_name: profile?.full_name || '',
    avatar_url: profile?.avatar_url || ''
  });
  
  const [settingsForm, setSettingsForm] = useState({
    theme_preference: settings?.theme_preference || 'system',
    language_preference: settings?.language_preference || 'nl',
    notification_preferences: settings?.notification_preferences || {
      email: true,
      push: true,
      marketing: false
    }
  });

  const handleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const result = await updateProfile(profileForm);
    if (!result?.error) {
      // Profile updated successfully
    }
  };

  const handleSettingsSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const result = await updateSettings(settingsForm);
    if (!result?.error) {
      // Settings updated successfully
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="glass-card rounded-3xl p-8 shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-xl font-bold text-white">User Profile</h2>
          <button
            onClick={onClose}
            className="w-10 h-10 rounded-2xl glass-button flex items-center justify-center text-white/70 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-8">
          <button
            onClick={() => setActiveTab('profile')}
            className={`px-6 py-3 rounded-2xl font-medium text-xs transition-all ${
              activeTab === 'profile'
                ? 'glass-gradient-button text-white'
                : 'glass-button text-white/70 hover:text-white'
            }`}
          >
            <User className="w-4 h-4 inline mr-2" />
            Profile
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`px-6 py-3 rounded-2xl font-medium text-xs transition-all ${
              activeTab === 'settings'
                ? 'glass-gradient-button text-white'
                : 'glass-button text-white/70 hover:text-white'
            }`}
          >
            <Settings className="w-4 h-4 inline mr-2" />
            Settings
          </button>
        </div>

        {/* Profile Tab */}
        {activeTab === 'profile' && (
          <form onSubmit={handleProfileSubmit} className="space-y-6">
            {/* Avatar Section */}
            <div className="text-center">
              <div className="relative inline-block">
                <div className="w-24 h-24 rounded-full glass-gradient-button flex items-center justify-center text-white font-bold text-2xl mb-4">
                  {profile?.avatar_url ? (
                    <img
                      src={profile.avatar_url}
                      alt="Avatar"
                      className="w-full h-full rounded-full object-cover"
                    />
                  ) : (
                    (profile?.full_name || profile?.email || 'U')[0].toUpperCase()
                  )}
                </div>
                <button
                  type="button"
                  className="absolute bottom-0 right-0 w-8 h-8 rounded-full glass-button flex items-center justify-center text-white/70 hover:text-white"
                >
                  <Camera className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Profile Fields */}
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-white/90 mb-2">
                  Full Name
                </label>
                <input
                  type="text"
                  value={profileForm.full_name}
                  onChange={(e) => setProfileForm({ ...profileForm, full_name: e.target.value })}
                  className="w-full p-3 glass-input rounded-2xl text-white placeholder-white/60 text-xs"
                  placeholder="Your full name"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-white/90 mb-2">
                  Email
                </label>
                <input
                  type="email"
                  value={profile?.email || ''}
                  disabled
                  className="w-full p-3 glass-input rounded-2xl text-white/50 text-xs cursor-not-allowed"
                />
                <p className="text-xs text-white/50 mt-1">Email cannot be changed</p>
              </div>

              <div>
                <label className="block text-xs font-medium text-white/90 mb-2">
                  Login Method
                </label>
                <div className="flex items-center gap-2">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                    profile?.provider === 'google' 
                      ? 'bg-red-500/20 text-red-300' 
                      : 'bg-blue-500/20 text-blue-300'
                  }`}>
                    {profile?.provider === 'google' ? 'Google' : 'Email'}
                  </span>
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                    profile?.email_verified 
                      ? 'bg-green-500/20 text-green-300' 
                      : 'bg-yellow-500/20 text-yellow-300'
                  }`}>
                    {profile?.email_verified ? 'Verified' : 'Unverified'}
                  </span>
                </div>
              </div>
            </div>

            <button
              type="submit"
              disabled={profileUpdating}
              className="w-full glass-gradient-button text-white py-3 rounded-2xl font-medium text-xs disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              <Save className="w-4 h-4" />
              {profileUpdating ? 'Saving...' : 'Save Profile'}
            </button>
          </form>
        )}

        {/* Settings Tab */}
        {activeTab === 'settings' && (
          <form onSubmit={handleSettingsSubmit} className="space-y-6">
            <div>
              <label className="block text-xs font-medium text-white/90 mb-2">
                Theme Preference
              </label>
              <select
                value={settingsForm.theme_preference}
                onChange={(e) => setSettingsForm({ ...settingsForm, theme_preference: e.target.value as any })}
                className="w-full p-3 glass-input rounded-2xl text-white text-xs"
              >
                <option value="light" className="bg-gray-800">Light</option>
                <option value="dark" className="bg-gray-800">Dark</option>
                <option value="system" className="bg-gray-800">System</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-white/90 mb-2">
                Language Preference
              </label>
              <select
                value={settingsForm.language_preference}
                onChange={(e) => setSettingsForm({ ...settingsForm, language_preference: e.target.value })}
                className="w-full p-3 glass-input rounded-2xl text-white text-xs"
              >
                <option value="nl" className="bg-gray-800">Nederlands</option>
                <option value="en" className="bg-gray-800">English</option>
                <option value="de" className="bg-gray-800">Deutsch</option>
                <option value="fr" className="bg-gray-800">Français</option>
                <option value="ar" className="bg-gray-800">العربية</option>
                <option value="sy" className="bg-gray-800">سوري</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-white/90 mb-4">
                Notification Preferences
              </label>
              <div className="space-y-3">
                <label className="flex items-center justify-between">
                  <span className="text-xs text-white/80">Email Notifications</span>
                  <input
                    type="checkbox"
                    checked={settingsForm.notification_preferences.email}
                    onChange={(e) => setSettingsForm({
                      ...settingsForm,
                      notification_preferences: {
                        ...settingsForm.notification_preferences,
                        email: e.target.checked
                      }
                    })}
                    className="w-4 h-4 rounded glass-input"
                  />
                </label>
                <label className="flex items-center justify-between">
                  <span className="text-xs text-white/80">Push Notifications</span>
                  <input
                    type="checkbox"
                    checked={settingsForm.notification_preferences.push}
                    onChange={(e) => setSettingsForm({
                      ...settingsForm,
                      notification_preferences: {
                        ...settingsForm.notification_preferences,
                        push: e.target.checked
                      }
                    })}
                    className="w-4 h-4 rounded glass-input"
                  />
                </label>
                <label className="flex items-center justify-between">
                  <span className="text-xs text-white/80">Marketing Emails</span>
                  <input
                    type="checkbox"
                    checked={settingsForm.notification_preferences.marketing}
                    onChange={(e) => setSettingsForm({
                      ...settingsForm,
                      notification_preferences: {
                        ...settingsForm.notification_preferences,
                        marketing: e.target.checked
                      }
                    })}
                    className="w-4 h-4 rounded glass-input"
                  />
                </label>
              </div>
            </div>

            <div className="glass-stats-card rounded-2xl p-4">
              <h4 className="text-sm font-semibold text-white mb-2">Account Information</h4>
              <div className="space-y-2 text-xs text-white/70">
                <div className="flex justify-between">
                  <span>Account Created:</span>
                  <span>{profile?.created_at ? new Date(profile.created_at).toLocaleDateString() : 'N/A'}</span>
                </div>
                <div className="flex justify-between">
                  <span>Last Login:</span>
                  <span>{settings?.last_login ? new Date(settings.last_login).toLocaleDateString() : 'N/A'}</span>
                </div>
              </div>
            </div>

            <button
              type="submit"
              disabled={settingsUpdating}
              className="w-full glass-gradient-button text-white py-3 rounded-2xl font-medium text-xs disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              <Save className="w-4 h-4" />
              {settingsUpdating ? 'Saving...' : 'Save Settings'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

export default UserProfile;