import React from 'react';
import LoadingDots from './LoadingDots';

const PhysicsSpheres: React.FC = () => {
  return (
    <div className="w-full h-full flex items-center justify-center">
      <LoadingDots />
    </div>
  );
};

export default PhysicsSpheres;