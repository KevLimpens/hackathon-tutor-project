import React, { useState, useEffect } from 'react';
import { BookOpen, Upload, Languages, MessageCircle, Star, Play, User as UserIcon } from 'lucide-react';
import { useTranslation } from './hooks/useTranslation';
import { useAuth } from './hooks/useAuth';
import { signOut } from './lib/supabase';
import LanguageDropdown from './components/LanguageDropdown';
import AuthForm from './components/AuthForm';
import UserProfile from './components/UserProfile';
import PhysicsSpheres from './components/PhysicsSpheres';
import AnimatedArrow from './components/AnimatedArrow';

function App() {
  const { t, currentLanguage, changeLanguage } = useTranslation();
  const { user, profile, loading, isAuthenticated } = useAuth();
  const [activeSection, setActiveSection] = useState('home');
  const [dutchProficiency, setDutchProficiency] = useState(0);
  const [showUserProfile, setShowUserProfile] = useState(false);
  const [isDemoMode, setIsDemoMode] = useState(false);

  const getProficiencyLabel = (level: number) => {
    switch (level) {
      case 0: return 'Beginner';
      case 1: return 'Basis';
      case 2: return 'Elementair';
      case 3: return 'Gemiddeld';
      case 4: return 'Gevorderd';
      case 5: return 'Vloeiend';
      default: return 'Beginner';
    }
  };

  const handleSignOut = async () => {
    if (isDemoMode) {
      setIsDemoMode(false);
      setActiveSection('home');
    } else {
      await signOut();
      setActiveSection('home');
    }
  };

  const handleDemoModeActivation = () => {
    setIsDemoMode(true);
    setActiveSection('home');
  };

  // Show loading spinner while checking auth state (but not in demo mode)
  if (loading && !isDemoMode) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center">
        <div className="glass-card rounded-3xl p-8 shadow-2xl">
          <div className="flex items-center gap-4">
            <div className="w-8 h-8 border-4 border-purple-500 border-t-transparent rounded-full animate-spin"></div>
            <span className="text-white font-medium">Laden...</span>
          </div>
        </div>
      </div>
    );
  }

  // Show auth form if not authenticated and not in demo mode
  if (!isAuthenticated && !isDemoMode) {
    return <AuthForm onSuccess={() => setActiveSection('home')} onDemoMode={handleDemoModeActivation} />;
  }

  const renderContent = () => {
    switch (activeSection) {
      case 'physics-demo':
        return (
          <div className="max-w-6xl mx-auto">
            <div className="glass-card rounded-3xl p-8 shadow-2xl mb-8">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-16 h-16 rounded-2xl glass-button flex items-center justify-center">
                  <Play className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-white">Physics Demonstration</h1>
                  <p className="text-xs text-white/80">Elastic collision and gravitational effects simulation</p>
                </div>
              </div>
              
              <div className="glass-input rounded-2xl p-4 min-h-[600px] flex items-center justify-center">
                <PhysicsSpheres />
              </div>
              
              <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="glass-stats-card rounded-2xl p-4">
                  <h3 className="text-sm font-semibold text-white mb-2">Red Sphere</h3>
                  <p className="text-xs text-white/70">Initiates movement and collision sequence</p>
                </div>
                <div className="glass-stats-card rounded-2xl p-4">
                  <h3 className="text-sm font-semibold text-white mb-2">White Sphere</h3>
                  <p className="text-xs text-white/70">Fixed central pivot point for collisions</p>
                </div>
                <div className="glass-stats-card rounded-2xl p-4">
                  <h3 className="text-sm font-semibold text-white mb-2">Blue Sphere</h3>
                  <p className="text-xs text-white/70">Responds to collision forces elastically</p>
                </div>
              </div>
            </div>
          </div>
        );

      case 'speech-tutor':
        return (
          <div className="max-w-4xl mx-auto">
            <div className="glass-card rounded-3xl p-8 shadow-2xl mb-8">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-16 h-16 rounded-2xl glass-button flex items-center justify-center">
                  <MessageCircle className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-white">{t('speech-tutor')}</h1>
                  <p className="text-xs text-white/80">{t('speech-recognition-desc')}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="glass-stats-card rounded-2xl p-6">
                  <h3 className="text-sm font-semibold text-white mb-4">Uitspraak Oefenen</h3>
                  <div className="space-y-4">
                    <button className="w-full p-4 glass-gradient-button text-white rounded-2xl font-medium text-xs">
                      <div className="font-medium">Nederlandse Klanken</div>
                      <div className="opacity-90">Oefen moeilijke Nederlandse uitspraak</div>
                    </button>
                    <button className="w-full p-4 glass-gradient-button text-white rounded-2xl font-medium text-xs">
                      <div className="font-medium">Conversatie Oefening</div>
                      <div className="opacity-90">Oefen dagelijkse gesprekken</div>
                    </button>
                    <button className="w-full p-4 glass-gradient-button text-white rounded-2xl font-medium text-xs">
                      <div className="font-medium">Accent Training</div>
                      <div className="opacity-90">Verbeter je Nederlandse accent</div>
                    </button>
                  </div>
                </div>
                
                <div className="glass-stats-card rounded-2xl p-6">
                  <h3 className="text-sm font-semibold text-white mb-4">Live Feedback</h3>
                  <div className="glass-input rounded-2xl p-4 mb-4 min-h-[200px] flex items-center justify-center">
                    <div className="text-center text-white/70">
                      <MessageCircle className="w-12 h-12 mx-auto mb-2 opacity-50" />
                      <p className="text-xs">Klik op de microfoon om te beginnen</p>
                    </div>
                  </div>
                  <button className="w-full glass-gradient-button text-white py-3 rounded-2xl font-medium text-xs">
                    Start Spraak Sessie
                  </button>
                </div>
              </div>
            </div>
          </div>
        );

      case 'upload-image':
        return (
          <div className="max-w-4xl mx-auto">
            <div className="glass-card rounded-3xl p-8 shadow-2xl mb-8">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-16 h-16 rounded-2xl glass-button flex items-center justify-center">
                  <Upload className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-white">{t('upload-image')}</h1>
                  <p className="text-xs text-white/80">{t('visual-learning-desc')}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div className="border-2 border-dashed border-white/30 rounded-2xl p-8 text-center hover:border-purple-400 transition-colors cursor-pointer glass-stats-card">
                    <Upload className="w-12 h-12 text-white/60 mx-auto mb-4" />
                    <h3 className="text-sm font-medium text-white mb-2">Upload een Afbeelding</h3>
                    <p className="text-xs text-white/70 mb-4">Sleep een afbeelding hierheen of klik om te selecteren</p>
                    <button className="glass-gradient-button text-white px-6 py-3 rounded-2xl font-medium text-xs">
                      Bestand Kiezen
                    </button>
                  </div>
                  
                  <div className="glass-stats-card rounded-2xl p-6">
                    <h3 className="text-sm font-semibold text-white mb-4">Ondersteunde Formaten</h3>
                    <div className="grid grid-cols-3 gap-3">
                      <div className="text-center p-3 glass-button rounded-xl">
                        <div className="font-medium text-white text-xs">JPG</div>
                      </div>
                      <div className="text-center p-3 glass-button rounded-xl">
                        <div className="font-medium text-white text-xs">PNG</div>
                      </div>
                      <div className="text-center p-3 glass-button rounded-xl">
                        <div className="font-medium text-white text-xs">WEBP</div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="glass-stats-card rounded-2xl p-6">
                  <h3 className="text-sm font-semibold text-white mb-4">Voorbeeld Resultaat</h3>
                  <div className="glass-input rounded-2xl p-4 mb-4 min-h-[200px] flex items-center justify-center">
                    <div className="text-center text-white/70">
                      <BookOpen className="w-12 h-12 mx-auto mb-2 opacity-50" />
                      <p className="text-xs">Gedetecteerde woorden verschijnen hier</p>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center p-2 glass-button rounded-xl">
                      <span className="font-medium text-white text-xs">Huis</span>
                      <span className="text-xs text-white/70">House</span>
                    </div>
                    <div className="flex justify-between items-center p-2 glass-button rounded-xl">
                      <span className="font-medium text-white text-xs">Boom</span>
                      <span className="text-xs text-white/70">Tree</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case 'personal-dictionary':
        return (
          <div className="max-w-4xl mx-auto">
            <div className="glass-card rounded-3xl p-8 shadow-2xl mb-8">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-16 h-16 rounded-2xl glass-button flex items-center justify-center">
                  <BookOpen className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-white">{t('personal-dictionary')}</h1>
                  <p className="text-xs text-white/80">{t('personal-dict-desc')}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                  <div className="glass-stats-card rounded-2xl p-6 mb-6">
                    <div className="flex gap-4 mb-4">
                      <input 
                        type="text" 
                        placeholder="Zoek in je woordenboek..." 
                        className="flex-1 p-3 glass-input rounded-2xl text-white placeholder-white/60 text-xs"
                      />
                      <button className="glass-gradient-button text-white px-6 py-3 rounded-2xl font-medium text-xs">
                        Zoeken
                      </button>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    {[
                      { word: 'Gezellig', translation: 'Cozy, pleasant atmosphere', category: 'Emoties', difficulty: 'Moeilijk' },
                      { word: 'Uitwaaien', translation: 'To go out for fresh air', category: 'Activiteiten', difficulty: 'Gemiddeld' },
                      { word: 'Borrel', translation: 'Informal drinks gathering', category: 'Sociaal', difficulty: 'Gemakkelijk' },
                    ].map((item, index) => (
                      <div key={index} className="glass-stats-card rounded-2xl p-4 shadow-sm">
                        <div className="flex justify-between items-start mb-2">
                          <h3 className="text-sm font-semibold text-white">{item.word}</h3>
                          <span className={`px-2 py-1 rounded-full text-xs font-medium glass-button ${
                            item.difficulty === 'Moeilijk' ? 'text-red-300' :
                            item.difficulty === 'Gemiddeld' ? 'text-yellow-300' :
                            'text-green-300'
                          }`}>
                            {item.difficulty}
                          </span>
                        </div>
                        <p className="text-white/80 mb-2 text-xs">{item.translation}</p>
                        <div className="flex justify-between items-center">
                          <span className="text-xs text-purple-300 font-medium">{item.category}</span>
                          <button className="text-xs glass-gradient-button text-white px-3 py-1 rounded-xl">
                            Oefen →
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="space-y-6">
                  <div className="glass-stats-card rounded-2xl p-6">
                    <h3 className="text-sm font-semibold text-white mb-4">Statistieken</h3>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-white/70 text-xs">Totaal woorden:</span>
                        <span className="font-semibold text-white text-xs">247</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/70 text-xs">Deze week:</span>
                        <span className="font-semibold text-green-300 text-xs">+12</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/70 text-xs">Beheerst:</span>
                        <span className="font-semibold text-blue-300 text-xs">189</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="glass-stats-card rounded-2xl p-6">
                    <h3 className="text-sm font-semibold text-white mb-4">Categorieën</h3>
                    <div className="space-y-2">
                      {['Emoties', 'Activiteiten', 'Sociaal', 'Werk', 'Familie'].map((category, index) => (
                        <button key={index} className="w-full text-left p-2 glass-button rounded-2xl text-white text-xs">
                          {category}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case 'interactive-translation':
        return (
          <div className="max-w-4xl mx-auto">
            <div className="glass-card rounded-3xl p-8 shadow-2xl mb-8">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-16 h-16 rounded-2xl glass-button flex items-center justify-center">
                  <Languages className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-white">{t('interactive-translation')}</h1>
                  <p className="text-xs text-white/80">{t('interactive-trans-desc')}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div className="glass-stats-card rounded-2xl p-6">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="text-sm font-semibold text-white">Van</h3>
                      <select className="p-2 glass-input rounded-2xl text-white text-xs">
                        <option className="bg-gray-800">Nederlands</option>
                        <option className="bg-gray-800">English</option>
                        <option className="bg-gray-800">Deutsch</option>
                      </select>
                    </div>
                    <textarea 
                      placeholder="Type hier je tekst om te vertalen..."
                      className="w-full h-32 p-4 glass-input rounded-2xl resize-none text-white placeholder-white/60 text-xs"
                    />
                  </div>
                  
                  <div className="glass-stats-card rounded-2xl p-6">
                    <h3 className="text-sm font-semibold text-white mb-4">Context Hulp</h3>
                    <div className="space-y-2">
                      <button className="w-full text-left p-3 glass-button rounded-2xl">
                        <div className="font-medium text-white text-xs">Formeel</div>
                        <div className="text-xs text-white/70">Voor zakelijke communicatie</div>
                      </button>
                      <button className="w-full text-left p-3 glass-button rounded-2xl">
                        <div className="font-medium text-white text-xs">Informeel</div>
                        <div className="text-xs text-white/70">Voor dagelijkse gesprekken</div>
                      </button>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-6">
                  <div className="glass-stats-card rounded-2xl p-6">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="text-sm font-semibold text-white">Naar</h3>
                      <select className="p-2 glass-input rounded-2xl text-white text-xs">
                        <option className="bg-gray-800">English</option>
                        <option className="bg-gray-800">Nederlands</option>
                        <option className="bg-gray-800">Deutsch</option>
                      </select>
                    </div>
                    <div className="w-full h-32 p-4 glass-input rounded-2xl flex items-center justify-center text-white/70 text-xs">
                      Vertaling verschijnt hier...
                    </div>
                  </div>
                  
                  <div className="glass-stats-card rounded-2xl p-6">
                    <h3 className="text-sm font-semibold text-white mb-4">Culturele Tips</h3>
                    <div className="glass-message rounded-2xl p-4">
                      <div className="font-medium text-yellow-300 mb-1 text-xs">💡 Tip</div>
                      <p className="text-white/80 text-xs">
                        In Nederland zeggen we "Hoe gaat het?" als informele begroeting, 
                        maar "Hoe maakt u het?" is formeler.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return (
          <>
            {/* Welkom Sectie */}
            <div className="mb-8">
              <div className="glass-card rounded-3xl p-8 shadow-2xl">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h1 className="text-xl font-bold text-white mb-2">
                      {isDemoMode ? 'Demo Modus - Welkom bij LUCA-Tutor!' : t('welcome-title')}
                    </h1>
                    <p className="text-xs text-white/80">
                      {isDemoMode ? 'Je bent nu in demo modus. Verken alle functies van LUCA-Tutor!' : t('welcome-description')}
                    </p>
                  </div>
                  <button
                    onClick={() => setShowUserProfile(true)}
                    className="w-16 h-16 rounded-full glass-gradient-button flex items-center justify-center text-white font-bold text-lg hover:scale-105 transition-transform"
                  >
                    {isDemoMode ? (
                      <span className="text-sm">DEMO</span>
                    ) : profile?.avatar_url ? (
                      <img
                        src={profile.avatar_url}
                        alt="Avatar"
                        className="w-full h-full rounded-full object-cover"
                      />
                    ) : (
                      <UserIcon className="w-8 h-8" />
                    )}
                  </button>
                </div>
              </div>
            </div>

            {/* Feature Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <button 
                onClick={() => setActiveSection('speech-tutor')}
                className="glass-stats-card rounded-2xl p-6 text-left hover:scale-105 transition-all duration-300"
              >
                <div className="w-12 h-12 rounded-2xl glass-button flex items-center justify-center mb-4">
                  <MessageCircle className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-sm font-semibold text-white mb-2">{t('speech-tutor')}</h3>
                <p className="text-xs text-white/70">{t('speech-recognition-desc')}</p>
              </button>

              <button 
                onClick={() => setActiveSection('upload-image')}
                className="glass-stats-card rounded-2xl p-6 text-left hover:scale-105 transition-all duration-300"
              >
                <div className="w-12 h-12 rounded-2xl glass-button flex items-center justify-center mb-4">
                  <Upload className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-sm font-semibold text-white mb-2">{t('upload-image')}</h3>
                <p className="text-xs text-white/70">{t('visual-learning-desc')}</p>
              </button>

              <button 
                onClick={() => setActiveSection('personal-dictionary')}
                className="glass-stats-card rounded-2xl p-6 text-left hover:scale-105 transition-all duration-300"
              >
                <div className="w-12 h-12 rounded-2xl glass-button flex items-center justify-center mb-4">
                  <BookOpen className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-sm font-semibold text-white mb-2">{t('personal-dictionary')}</h3>
                <p className="text-xs text-white/70">{t('personal-dict-desc')}</p>
              </button>

              <button 
                onClick={() => setActiveSection('interactive-translation')}
                className="glass-stats-card rounded-2xl p-6 text-left hover:scale-105 transition-all duration-300"
              >
                <div className="w-12 h-12 rounded-2xl glass-button flex items-center justify-center mb-4">
                  <Languages className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-sm font-semibold text-white mb-2">{t('interactive-translation')}</h3>
                <p className="text-xs text-white/70">{t('interactive-trans-desc')}</p>
              </button>
            </div>

            {/* Call to Action */}
            <div className="mt-12">
              <div className="glass-card rounded-3xl p-8 shadow-2xl text-center">
                <h2 className="text-xl font-bold text-white mb-4">
                  {t('ready-title')}
                </h2>
                <p className="text-xs text-white/80 mb-6 max-w-2xl mx-auto">
                  {t('ready-description')}
                </p>
                <div className="flex justify-center gap-4">
                  <button 
                    onClick={() => setActiveSection('physics-demo')}
                    className="px-6 py-3 glass-gradient-button text-white font-semibold rounded-2xl shadow-lg text-xs"
                  >
                    Physics Demo
                  </button>
                  <button className="px-8 py-4 glass-gradient-button text-white font-semibold rounded-2xl shadow-lg text-xs">
                    {t('start-learning')}
                  </button>
                </div>
              </div>
            </div>
          </>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      <nav className="fixed top-0 w-full h-16 glass-nav shadow-2xl z-50">
        <div className="max-w-7xl mx-auto px-4 h-full flex items-center justify-between">
          <div className="flex gap-3">
            <button 
              onClick={() => setActiveSection('speech-tutor')}
              className={`px-4 py-2 rounded-2xl text-xs font-medium shadow-lg glass-nav-button ${
                activeSection === 'speech-tutor' ? 'active' : ''
              }`}
            >
              {t('speech-tutor')}
            </button>
            <button 
              onClick={() => setActiveSection('upload-image')}
              className={`px-4 py-2 rounded-2xl text-xs font-medium shadow-lg glass-nav-button ${
                activeSection === 'upload-image' ? 'active' : ''
              }`}
            >
              {t('upload-image')}
            </button>
            <button 
              onClick={() => setActiveSection('personal-dictionary')}
              className={`px-4 py-2 rounded-2xl text-xs font-medium shadow-lg glass-nav-button ${
                activeSection === 'personal-dictionary' ? 'active' : ''
              }`}
            >
              {t('personal-dictionary')}
            </button>
            <button 
              onClick={() => setActiveSection('interactive-translation')}
              className={`px-4 py-2 rounded-2xl text-xs font-medium shadow-lg glass-nav-button ${
                activeSection === 'interactive-translation' ? 'active' : ''
              }`}
            >
              {t('interactive-translation')}
            </button>
          </div>
          <div className="flex items-center gap-4">
            {/* Prominent Native Language Selector - First */}
            <div className="glass-language-selector rounded-full p-1 shadow-lg">
              <div className="flex items-center gap-2 px-3 py-1">
                <AnimatedArrow />
                <span className="text-xs font-medium text-white scale-105">{t('native-language')}:</span>
                <LanguageDropdown 
                  currentLanguage={currentLanguage}
                  onLanguageChange={changeLanguage}
                />
              </div>
            </div>
            
            {/* Dutch Proficiency Selector - Second */}
            <div className="flex items-center gap-3 px-4 py-2 glass-nav-button rounded-2xl">
              <span className="text-xs font-medium text-white/90">Nederlands niveau:</span>
              <div className="flex items-center gap-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    onClick={() => setDutchProficiency(star)}
                    className="transition-all duration-200 hover:scale-110"
                  >
                    <Star 
                      className={`w-3 h-3 ${
                        star <= dutchProficiency 
                          ? 'text-yellow-400 fill-yellow-400' 
                          : 'text-white/30 hover:text-yellow-300'
                      }`}
                    />
                  </button>
                ))}
              </div>
              <span className="text-xs text-white/70 font-medium min-w-[60px]">
                {getProficiencyLabel(dutchProficiency)}
              </span>
            </div>
            
            {/* Home Button - Third */}
            <button 
              onClick={() => setActiveSection('home')}
              className={`px-4 py-2 rounded-2xl text-xs font-medium glass-nav-button ${
                activeSection === 'home' ? 'active' : ''
              }`}
            >
              Home
            </button>

            {/* User Profile & Logout */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowUserProfile(true)}
                className="w-8 h-8 rounded-full glass-gradient-button flex items-center justify-center text-white font-bold text-xs hover:scale-105 transition-transform"
              >
                {isDemoMode ? (
                  <span className="text-xs">D</span>
                ) : profile?.avatar_url ? (
                  <img
                    src={profile.avatar_url}
                    alt="Avatar"
                    className="w-full h-full rounded-full object-cover"
                  />
                ) : (
                  <UserIcon className="w-4 h-4" />
                )}
              </button>
              <button 
                onClick={handleSignOut}
                className="px-4 py-2 rounded-2xl text-xs font-medium glass-nav-button text-white/90"
              >
                {isDemoMode ? 'Demo Verlaten' : 'Uitloggen'}
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="pt-20 min-h-screen">
        <div className="max-w-7xl mx-auto p-6">
          {renderContent()}
        </div>
      </main>

      {/* User Profile Modal */}
      <UserProfile 
        isOpen={showUserProfile}
        onClose={() => setShowUserProfile(false)}
      />
    </div>
  );
}

export default App;