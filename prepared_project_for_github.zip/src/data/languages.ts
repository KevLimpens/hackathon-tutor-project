import { Language } from '../types/language';

export const languages: Language[] = [
  { 
    code: 'nl', 
    name: 'Nederlands', 
    flag: 'https://flagcdn.com/24x18/nl.png'
  },
  { 
    code: 'de', 
    name: 'Deutsch', 
    flag: 'https://flagcdn.com/24x18/de.png'
  },
  { 
    code: 'en', 
    name: 'English', 
    flag: 'https://flagcdn.com/24x18/gb.png'
  },
  { 
    code: 'ar', 
    name: 'العربية', 
    flag: 'https://flagcdn.com/24x18/sa.png'
  },
  { 
    code: 'sy', 
    name: 'سوري', 
    flag: 'https://flagcdn.com/24x18/sy.png'
  },
  { 
    code: 'fr', 
    name: 'Français', 
    flag: 'https://flagcdn.com/24x18/fr.png'
  },
];