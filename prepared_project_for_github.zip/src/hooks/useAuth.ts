import { useState, useEffect } from 'react'
import { User as SupabaseUser } from '@supabase/supabase-js'
import { supabase, isSupabaseConfigured, getUserProfile, getUserSettings, User, UserSettings } from '../lib/supabase'

interface AuthState {
  user: SupabaseUser | null
  profile: User | null
  settings: UserSettings | null
  loading: boolean
  isAuthenticated: boolean
  isSupabaseConfigured: boolean
}

export const useAuth = (): AuthState => {
  const [user, setUser] = useState<SupabaseUser | null>(null)
  const [profile, setProfile] = useState<User | null>(null)
  const [settings, setSettings] = useState<UserSettings | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // If Supabase is not configured, create mock state for development
    if (!isSupabaseConfigured()) {
      console.log('Supabase not configured - using mock auth state')
      setLoading(false)
      
      // Create mock authenticated state for development
      const mockUser = {
        id: 'demo-user-id',
        email: 'demo@taal-tutor.nl',
        user_metadata: { full_name: 'Taal Tutor Demo' }
      } as SupabaseUser
      
      const mockProfile = {
        id: 'demo-user-id',
        email: 'demo@taal-tutor.nl',
        full_name: 'Taal Tutor Demo',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        provider: 'email' as const,
        email_verified: true
      } as User

      const mockSettings = {
        user_id: 'demo-user-id',
        notification_preferences: {
          email: true,
          push: true,
          marketing: false
        },
        theme_preference: 'system' as const,
        language_preference: 'nl',
        last_login: new Date().toISOString(),
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      } as UserSettings

      setUser(mockUser)
      setProfile(mockProfile)
      setSettings(mockSettings)
      return
    }

    // Get initial session
    const getInitialSession = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession()
        const currentUser = session?.user ?? null
        setUser(currentUser)

        if (currentUser) {
          // Fetch user profile and settings
          const [profileResult, settingsResult] = await Promise.all([
            getUserProfile(currentUser.id),
            getUserSettings(currentUser.id)
          ])

          if (profileResult.data) {
            setProfile(profileResult.data)
          }
          if (settingsResult.data) {
            setSettings(settingsResult.data)
          }
        }
      } catch (error) {
        console.error('Error getting session:', error)
        setUser(null)
        setProfile(null)
        setSettings(null)
      } finally {
        setLoading(false)
      }
    }

    getInitialSession()

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        console.log('Auth state changed:', event, session?.user?.email)
        const currentUser = session?.user ?? null
        setUser(currentUser)

        if (currentUser) {
          // Fetch user profile and settings on auth change
          const [profileResult, settingsResult] = await Promise.all([
            getUserProfile(currentUser.id),
            getUserSettings(currentUser.id)
          ])

          if (profileResult.data) {
            setProfile(profileResult.data)
          }
          if (settingsResult.data) {
            setSettings(settingsResult.data)
          }
        } else {
          setProfile(null)
          setSettings(null)
        }
        
        setLoading(false)
      }
    )

    return () => subscription.unsubscribe()
  }, [])

  const isAuthenticated = !!user

  console.log('Auth state:', { 
    hasUser: !!user, 
    hasProfile: !!profile, 
    loading, 
    isAuthenticated,
    isSupabaseConfigured: isSupabaseConfigured()
  })

  return {
    user,
    profile,
    settings,
    loading,
    isAuthenticated,
    isSupabaseConfigured: isSupabaseConfigured()
  }
}

// Hook for managing user profile
export const useUserProfile = () => {
  const { user, profile } = useAuth()
  const [updating, setUpdating] = useState(false)

  const updateProfile = async (updates: Partial<User>) => {
    if (!user) return { error: new Error('No user logged in') }

    setUpdating(true)
    try {
      if (!isSupabaseConfigured()) {
        // Mock update for demo mode
        console.log('Mock profile update:', updates)
        return { data: { ...profile, ...updates }, error: null }
      }

      // Real Supabase update
      const { updateUserProfile } = await import('../lib/supabase')
      const result = await updateUserProfile(user.id, updates)
      return result
    } finally {
      setUpdating(false)
    }
  }

  return {
    profile,
    updateProfile,
    updating
  }
}

// Hook for managing user settings
export const useUserSettings = () => {
  const { user, settings } = useAuth()
  const [updating, setUpdating] = useState(false)

  const updateSettings = async (updates: Partial<UserSettings>) => {
    if (!user) return { error: new Error('No user logged in') }

    setUpdating(true)
    try {
      if (!isSupabaseConfigured()) {
        // Mock update for demo mode
        console.log('Mock settings update:', updates)
        return { data: { ...settings, ...updates }, error: null }
      }

      // Real Supabase update
      const { updateUserSettings } = await import('../lib/supabase')
      const result = await updateUserSettings(user.id, updates)
      return result
    } finally {
      setUpdating(false)
    }
  }

  return {
    settings,
    updateSettings,
    updating
  }
}