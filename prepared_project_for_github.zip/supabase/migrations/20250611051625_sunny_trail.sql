/*
  # Fix missing auth trigger

  1. Problem
    - The `on_auth_user_created` trigger is missing from the database
    - This prevents new users from being automatically added to the `users` table
    - Users can authenticate but their profile data isn't created

  2. Solution
    - Add the missing trigger that calls `handle_new_user()` function
    - Ensure the trigger fires on both INSERT and UPDATE of auth.users
    - Use IF NOT EXISTS pattern to prevent conflicts

  3. Security
    - No changes to existing RLS policies
    - Maintains existing security model
*/

-- Ensure the trigger exists for new user creation
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT OR UPDATE ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();